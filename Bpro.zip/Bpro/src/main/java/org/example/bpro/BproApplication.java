package org.example.bpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BproApplication {

    public static void main(String[] args) {
        SpringApplication.run(BproApplication.class, args);
    }

}
