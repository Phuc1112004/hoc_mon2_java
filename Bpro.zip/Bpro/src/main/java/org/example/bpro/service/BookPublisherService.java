package org.example.bpro.service;

import org.example.bpro.entity.BookPublisher;
import org.example.bpro.repository.BookPublisherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookPublisherService {
    @Autowired
    private BookPublisherRepository bookPublisherRepository;

    public List<BookPublisher> getAllBookPublishers() {
        return bookPublisherRepository.findAll();
    }

    public BookPublisher getBookPublisherById(Long id) {
        return bookPublisherRepository.findById(id).orElse(null);
    }

    public void saveBookPublisher(BookPublisher bookPublisher) {
        bookPublisherRepository.save(bookPublisher);
    }

    public void deleteBookPublisher(Long id) {
        bookPublisherRepository.deleteById(id);
    }
}
