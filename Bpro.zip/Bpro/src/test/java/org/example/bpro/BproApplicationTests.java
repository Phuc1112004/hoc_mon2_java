package org.example.bpro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BproApplicationTests {

    @Test
    void contextLoads() {
    }

}
